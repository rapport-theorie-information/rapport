import numpy as np
from scipy.linalg import sqrtm
import matplotlib.pyplot as plt
n = 10000  
mu = np.array([1, 2])  
R = np.array([[2, 1], [1, 2]])  
Z = np.random.randn(n, len(mu))
L = sqrtm(R)
X = mu + np.dot(Z, np.transpose(L))
nbins = 40
hist, xedges, yedges = np.histogram2d(X[:, 0], X[:, 1], bins=nbins, density=True)

step = 10**(-3)
theta = np.arange(0, 2*np.pi, step)
w = np.array([np.cos(theta), np.sin(theta)])
x1 = np.dot(sqrtm(R), w) + np.outer(mu, np.ones(len(theta)))
x2 = np.sqrt(5) * np.dot(sqrtm(R), w) + np.outer(mu, np.ones(len(theta)))
x3 = np.sqrt(10) * np.dot(sqrtm(R), w) + np.outer(mu, np.ones(len(theta)))

plt.figure()
plt.bar(xedges[:-1], hist.sum(axis=0), align='edge', width=xedges[1] - xedges[0])
plt.plot(x1[0], x1[1], label='Contour 1')
plt.plot(x2[0], x2[1], label='Contour 2')
plt.plot(x3[0], x3[1], label='Contour 3')

plt.show()
