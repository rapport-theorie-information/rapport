from scipy.io import loadmat 
Statis = loadmat('pluv.mat')
